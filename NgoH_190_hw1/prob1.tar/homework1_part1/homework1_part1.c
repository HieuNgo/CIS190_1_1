/*Hieu Ngo
9/26/2017
Part 1 of homework 1, cis 190
Teach simple multiplication
*/


#include <stdlib.h>
#include <stdio.h>
#include <time.h>

int main()
{
	//declare variable	
	int temp1,temp2,product,answer;
	int rand1,rand2,i=0,count=0;
	float percentage;

	//initialize rng
	srand(time(NULL));
	
	while(i<10)
	{
		//create three random 1-digit numbers and calculate product of the first two
		temp1 = rand()%10;
		temp2 = rand()%10;

		product = temp1 * temp2;
		
		do 
		{
			//ask the students for the answer
			printf("How much is %d times %d? \n",temp1,temp2);
			scanf("%d",&answer);
			
			//count the number of total answer.	
			i++;

			//random for the switch statements
			rand1 = rand()%4;
			rand2 = rand()%4;
			
			//compare the answer with product and print a response
			if (answer == product)
			{
				//count the number of correct answer.
				count++;

				switch(rand1) 
				{
					case 0:
					printf("Very good!\n");
					break;			
					case 1:
					printf("Excellent\n");
					break;			
					case 2:
					printf("Nice work!\n");
					break;			
					case 3:
					printf("Keep up the good work\n");
					break;		
				}
			}
			else
			{
				switch(rand2) 
				{
					case 0:
					printf("No. Please try again.\n");
					break;			
					case 1:
					printf("Wrong. Try one more.\n");
					break;
					case 2:
					printf("Don't give up!\n");
					break;
					case 3:
					printf("No. Keep trying.\n");
					break;		
				}
				if (i >= 10)
				break;
			}		
		} while(answer != product);
	}
	printf("You have %d correct answers out of %d answers\n",count,i);

	//calculate percentage of correct response then print if percentage < 75%
	percentage = (float)count / (float)i;
	if (percentage < 0.75) 
	{
		printf("Please ask your instructor for extra help\n");	
	}

	return 0;
}
