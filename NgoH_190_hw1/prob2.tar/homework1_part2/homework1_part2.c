/*Hieu Ngo
9/26/2017
Part 2 of homework 1, cis 190

*/


#include <stdlib.h>
#include <stdio.h>
#include <time.h>

int main()
{
	//declare variable	
	int temp1,temp2, i;
	int hundreds1, tens1, numb1;
	int hundreds2, tens2, numb2;	
		
	//initialize rng
	srand(time(NULL));

	//print out the rules
	printf(" Today we will play a game, you take ten guesses of a 3 digit number, \n");
	printf(" and I will tell you which one is a match or hit");

	//create a unique 3 digits number without repetition of digits
	hundreds1 = rand() % 9 +1;
	do 
	{
		tens1 = rand() % 10;
	} while(tens1 == hundreds1);
	do 
	{
		numb1 = rand() % 10;
	} while(numb1 == tens1 || numb1 == hundreds1);
	
	temp1 = (hundreds1*100) + (tens1*10) + numb1;
	
	for(i=0;i<10;i++)
	{
		//ask the user for their guess.
		printf("This is your number %d guess.\n", i+1);
		printf("What is your guess?\n");
		scanf("%d",&temp2);
		
		//check if user input is valid
		if (temp2<100 || temp2 > 999)
		{
			printf("your guess is invalid. Please try again\n");
			i--;
			continue;
		}
		//separate temp2 into separate digit
		hundreds2 = temp2 / 100;
		tens2 = temp2 /10 % 10;
		numb2 = temp2 % 10;

		//compare these digits with the answer
		if ( hundreds2 == hundreds1)
			printf("Number %d is a hit.\n", hundreds1);
		else if (hundreds2 == tens1 || hundreds2 == numb1)
			printf("Number %d is a match.\n", hundreds2);

		if ( tens2 == tens1)
			printf("Number %d is a hit.\n", tens1);
		else if (tens2 == hundreds1 || tens2 == numb1)
			printf("Number %d is a match.\n", tens2);

		if ( numb2 == numb1)
			printf("Number %d is a hit.\n", numb1);
		else if (numb2 == hundreds1 || numb2 == tens1)
			printf("Number %d is a match.\n", numb2);

		if (temp2 == temp1)
		{
			printf("Congratulations, you correctly guesses %d\n",temp1);
			break;
		}
	}
	return 0;
}









